# Extraction status

- [ ] Extract installer payload
- [ ] Inventory file signatures
- [ ] Identify model/animation/texture containers
- [ ] Write parser
- [ ] Validate extracted data
- [ ] Convert to Godot-compatible formats

No extracted model/animation files are verified at this stage.
