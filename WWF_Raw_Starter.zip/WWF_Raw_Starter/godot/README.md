# Godot game prototype

No game scenes/scripts have been added yet. The game prototype will begin after source format investigation. Planned mobile target: landscape, touch controls, ring arena, player-vs-AI match, and importable character/animation assets only after validation.
